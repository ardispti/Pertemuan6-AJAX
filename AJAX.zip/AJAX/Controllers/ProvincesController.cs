﻿using AJAXv1.Context;
using AJAXv1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AJAXv1.Controllers
{
    public class ProvincesController : Controller
    {
        MyContext myContext = new MyContext();

        // GET: Provinces
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetProvinces()
        {
            List<Province> Provinces = new List<Province>();
            Provinces = myContext.Provinces.ToList();
            return Json(Provinces, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetProvince(int id)
        {
            var Province = new Province();
            Province = myContext.Provinces.Find(id);
            return Json(Province, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Post(Province Province)
        {
            myContext.Provinces.Add(Province);
            var result = myContext.SaveChanges();
            if (result > 0)
                return Json(200, JsonRequestBehavior.AllowGet);
            return Json(400, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Edit(Province Province)
        {
            var get = myContext.Provinces.Find(Province.Id);
            if (get != null)
            {
                if (TryUpdateModel(get, "", new string[] { "Name" }))
                {
                    myContext.SaveChanges();
                    return Json(200, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(400, JsonRequestBehavior.AllowGet);
                }
            }

            return Json(400, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Delete(int id)
        {
            var get = myContext.Provinces.Find(id);
            if (get != null)
            {
                myContext.Provinces.Remove(get);
                var result = myContext.SaveChanges();
                if (result > 0)
                    return Json(200, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(404, JsonRequestBehavior.AllowGet);
            }
            return Json(400, JsonRequestBehavior.AllowGet);
        }
    }
}